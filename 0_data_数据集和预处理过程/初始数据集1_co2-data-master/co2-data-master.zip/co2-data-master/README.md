# Data on CO2 and Greenhouse Gas Emissions by *Our World in Data*

Our complete CO2 and Greenhouse Gas Emissions dataset is a collection of key metrics maintained by [*Our World in Data*](https://ourworldindata.org/co2-and-other-greenhouse-gas-emissions). It is updated regularly and includes data on CO2 emissions (annual, per capita, cumulative and consumption-based), other greenhouse gases, energy mix, and other relevant metrics.

## The complete *Our World in Data* CO2 and Greenhouse Gas Emissions dataset

### 🗂️ Download our complete CO2 and Greenhouse Gas Emissions dataset : [CSV](https://owid-public.owid.io/data/co2/owid-co2-data.csv) | [XLSX](https://owid-public.owid.io/data/co2/owid-co2-data.xlsx) | [JSON](https://owid-public.owid.io/data/co2/owid-co2-data.json)

The CSV and XLSX files follow a format of 1 row per location and year. The JSON version is split by country, with an array of yearly records.

The indicators represent all of our main data related to CO2 emissions, other greenhouse gas emissions, energy mix, as well as other indicators of potential interest.

We will continue to publish updated data on CO2 and Greenhouse Gas Emissions as it becomes available. Most metrics are published on an annual basis.

A [full codebook](https://github.com/owid/co2-data/blob/master/owid-co2-codebook.csv) is made available, with a description and source for each indicator in the dataset. This codebook is also included as an additional sheet in the XLSX file.

## Our source data and code

The dataset is built upon a number of datasets and processing steps:

- Global carbon budget - Global Carbon Project:
  - [Source data](https://globalcarbonbudgetdata.org/)
  - [Ingestion code](https://github.com/owid/etl/blob/master/snapshots/gcp/2025-11-13/global_carbon_budget.py)
  - [Basic processing code](https://github.com/owid/etl/blob/master/etl/steps/data/meadow/gcp/2025-11-13/global_carbon_budget.py)
  - [Further processing code](https://github.com/owid/etl/blob/master/etl/steps/data/garden/gcp/2025-11-13/global_carbon_budget.py)
- National contributions to climate change - Jones et al.:
  - [Source data](https://zenodo.org/records/7636699/latest)
  - [Ingestion code](https://github.com/owid/etl/blob/master/snapshots/emissions/2025-12-04/national_contributions.py)
  - [Basic processing code](https://github.com/owid/etl/blob/master/etl/steps/data/meadow/emissions/2025-12-04/national_contributions.py)
  - [Further processing code](https://github.com/owid/etl/blob/master/etl/steps/data/garden/emissions/2025-12-04/national_contributions.py)
- Our World in data's CO2 dataset (based on all sources above):
  - [Processing code](https://github.com/owid/etl/blob/master/etl/steps/data/garden/emissions/2025-12-04/owid_co2.py)
  - [Exporting code](https://github.com/owid/etl/blob/master/etl/steps/export/github/co2_data/latest/owid_co2.py)
  - [Uploading code](https://github.com/owid/etl/blob/master/etl/steps/export/s3/co2_data/latest/owid_co2.py)

Additionally, to construct indicators per capita, per GDP, and per unit energy, we use the following datasets and processing steps:
- Regions (Our World in Data).
  - [Processing code](https://github.com/owid/etl/blob/master/etl/steps/data/garden/regions/2023-01-01/regions.py)
- Population (Our World in Data based on [a number of different sources](https://ourworldindata.org/population-sources)).
  - [Processing code](https://github.com/owid/etl/blob/master/etl/steps/data/garden/demography/2024-07-15/population.py)
- Income groups (World Bank).
  - [Processing code](https://github.com/owid/etl/blob/master/etl/steps/data/garden/wb/2025-07-01/income_groups.py)
- GDP (University of Groningen GGDC's Maddison Project Database, Bolt and van Zanden).
  - [Ingestion code](https://github.com/owid/etl/blob/master/snapshots/ggdc/2024-04-26/maddison_project_database.py)
  - [Basic processing code](https://github.com/owid/etl/blob/master/etl/steps/data/meadow/ggdc/2024-04-26/maddison_project_database.py)
  - [Processing code](https://github.com/owid/etl/blob/master/etl/steps/data/garden/ggdc/2024-04-26/maddison_project_database.py)
- Statistical review of world energy (Energy Institute, EI):
  - [Source data](https://www.energyinst.org/statistical-review)
  - [Ingestion code](https://github.com/owid/etl/blob/master/snapshots/energy_institute/2025-06-27/statistical_review_of_world_energy.py)
  - [Basic processing code](https://github.com/owid/etl/blob/master/etl/steps/data/meadow/energy_institute/2025-06-27/statistical_review_of_world_energy.py)
  - [Further processing code](https://github.com/owid/etl/blob/master/etl/steps/data/garden/energy_institute/2025-06-27/statistical_review_of_world_energy.py)
- International energy data (U.S. Energy Information Administration, EIA):
  - [Source data](https://www.eia.gov/opendata/bulkfiles.php)
  - [Ingestion code](https://github.com/owid/etl/blob/master/snapshots/eia/2026-05-05/international_energy.zip.dvc)
  - [Basic processing code](https://github.com/owid/etl/blob/master/etl/steps/data/meadow/eia/2026-05-05/international_energy.py)
  - [Further processing code](https://github.com/owid/etl/blob/master/etl/steps/data/garden/eia/2026-05-05/international_energy.py)
- Primary energy consumption (EI's Statistical review of world energy & EIA's International energy data):
  - [Processing code](https://github.com/owid/etl/blob/master/etl/steps/data/garden/energy/2026-05-05/primary_energy_consumption.py)

## Changelog

- 2026-06-01:
  - Update dataset to use the latest EIA's International Energy Data.
  - Changed the units of the carbon intensity of energy indicators from kilograms to grams of CO₂ per kilowatt-hour.
- 2025-12-04:
  - Update greenhouse gases using the latest data from Jones et al. (2025).
- 2025-11-13:
  - Updated dataset to use the latest version of the Global Carbon Budget (2025).
- 2024-11-21:
  - Updated dataset (and codebook) to use the latest version of the Global Carbon Budget (2024), and Jones et al. (2024) (version 2024.2).
  - Now methane, nitrous oxide, and total greenhouse gas emissions data come from Jones et al. (2024), instead of Climate Watch, to provide a wider data coverage.
- 2024-06-20:
  - Update data from the Statistical Review of World Energy.
  - Update data from the Maddison Project Database.
- 2024-04-10:
  - Updated dataset and codebook to use the latest version of the data on National contributions to climate change (Jones et al. (2024)).
- 2023-12-28:
  - Enhanced codebook (improved descriptions, added units, updated sources).
  - Updated primary energy consumption (to update metadata, nothing has changed in the data).
- 2023-12-05:
  - Updated dataset (and codebook) to use the latest version of the Global Carbon Budget (2023).
    - In this version, "International transport" has been replaced by "International aviation" and "International shipping". Also, some overseas territories have no data in this version. More details on the changes can be found in the pdf file hosted [here](https://zenodo.org/records/10177738).
- 2023-11-08:
  - Updated CO2 emissions data to use the latest emissions by sector from Climate Watch (2023).
  - Update codebook accordingly.
- 2023-10-16:
  - Improved codebook.
  - Fixed issue related to consumption-based emissions in Africa, and Palau emissions.
- 2023-07-10:
  - Updated primary energy consumption and other indicators relying on energy data, to use the latest Statistical Review of World Energy by the Energy Institute.
  - Renamed countries 'East Timor' and 'Faroe Islands'.
- 2023-05-04:
  - Added indicators `share_of_temperature_change_from_ghg`, `temperature_change_from_ch4`, `temperature_change_from_co2`, `temperature_change_from_ghg`, and `temperature_change_from_n2o` using data from Jones et al. (2023).
- 2022-11-11:
  - Updated CO2 emissions data with the newly released Global Carbon Budget (2022) by the Global Carbon Project.
  - Added various new indicators related to national land-use change emissions.
  - Added the emissions of the 1991 Kuwaiti oil fires in Kuwait's emissions (while also keeping 'Kuwaiti Oil Fires (GCP)' as a separate entity), to properly account for these emissions in the aggregate of Asia.
  - Applied minor changes to entity names (e.g. "Asia (excl. China & India)" -> "Asia (excl. China and India)").
- 2022-09-06:
  - Updated data on primary energy consumption (from BP & EIA) and greenhouse gas emissions by sector (from CAIT).
  - Refactored code, since now this repository simply loads the data, generates the output files, and uploads them to the cloud; the code to generate the dataset is now in our [etl repository](https://github.com/owid/etl).
  - Minor changes in the codebook.
- 2022-04-15:
  - Updated primary energy consumption data.
  - Updated CO2 data to include aggregations for the different country income levels.
- 2022-02-24:
  - Updated greenhouse gas emissions data from CAIT Climate Data Explorer.
  - Included two new columns in dataset: total greenhouse gases excluding land-use change and forestry, and the same as per capita values.
- 2021-11-05:
  - Updated CO2 emissions data with the newly released Global Carbon Budget (v2021).
- 2021-09-16:
  - Fixed data quality issues in CO2 emissions indicators (emissions less than 0, missing data for Eswatini, ...).
  - Replaced all input CSVs with data retrieved directly from ourworldindata.org.
- 2021-02-08:
  - Updated this dataset with the latest annual release from the Global Carbon Project.
- 2020-08-07:
  - The first version of this dataset was made available.

## Data processing

- **We standardize names of countries and regions.** Since the names of countries and regions are different in different data sources, we standardize all names in order to minimize data loss during data merges.
- **We recalculate carbon emissions to CO2.** The primary data sources on CO2 emissions—the Global Carbon Project, for example—typically report emissions in tonnes of carbon. We have recalculated these figures as tonnes of CO2 using a conversion factor of 3.664.
- **We calculate per capita figures.** All of our per capita figures are calculated from our metric `population`, which is included in the complete dataset.
- **We create aggregate data for regions (e.g. Africa, Europe, etc.).** Since regions are defined differently by our sources, we create our own aggregates following [*Our World in Data* region definitions](https://ourworldindata.org/world-region-map-definitions).
  - We also include data for regions as defined in the original datasets; for example, `Europe (EI)` corresponds to Europe as defined by the Energy Institute.

## License

All visualizations, data, and code produced by _Our World in Data_ are completely open access under the [Creative Commons BY license](https://creativecommons.org/licenses/by/4.0/). You have the permission to use, distribute, and reproduce these in any medium, provided the source and authors are credited.

The data produced by third parties and made available by _Our World in Data_ is subject to the license terms from the original third-party authors. We will always indicate the original source of the data in our database, and you should always check the license of any such third-party data before use.

## Authors

This data has been collected, aggregated, and documented by Pablo Rosado, Hannah Ritchie, Max Roser, Edouard Mathieu, and Bobbie Macdonald.

The mission of *Our World in Data* is to make data and research on the world's largest problems understandable and accessible. [Read more about our mission](https://ourworldindata.org/about).

## How to cite this data?

If you are using this dataset, please cite both [Our World in Data](https://ourworldindata.org/co2-and-greenhouse-gas-emissions#article-citation) and the underlying data source(s).

Please follow [the guidelines in our FAQ](https://ourworldindata.org/faqs#how-should-i-cite-your-data) on how to cite our work.

